%DEMO_QUICK_START  Minimal CLCO example -- runs out of the box, no data files.
%
%   Optimises three classic test functions in 30 dimensions with the paper's
%   benchmark protocol (N = 30, T = 500) and plots the convergence curves.
%
%   Usage:  run this file from the directory that contains CLCO.m.

clear; clc; close all;
addpath(fileparts(mfilename('fullpath')));

N   = 30;    % population size (coordination number)
T   = 500;   % maximum iterations
dim = 30;    % problem dimension

funcs = { ...
    'Sphere',    @(x) sum(x.^2),                                       -100, 100; ...
    'Rastrigin', @(x) sum(x.^2 - 10*cos(2*pi*x) + 10),                -5.12, 5.12; ...
    'Ackley',    @(x) -20*exp(-0.2*sqrt(mean(x.^2))) - ...
                       exp(mean(cos(2*pi*x))) + 20 + exp(1),            -32, 32 };

figure('Name', 'CLCO quick start', 'Color', 'w');
for k = 1:size(funcs, 1)
    name = funcs{k, 1};
    fobj = funcs{k, 2};
    lb   = funcs{k, 3};
    ub   = funcs{k, 4};

    opts = struct('seed', 1);   % reproducible run
    tic;
    [best_x, best_f, curve, nfe] = CLCO(N, T, lb, ub, dim, fobj, opts);
    elapsed = toc;

    fprintf('%-10s  best = %.6e   nfe = %d   time = %.2f s\n', ...
            name, best_f, nfe, elapsed);

    subplot(1, size(funcs, 1), k);
    semilogy(curve, 'LineWidth', 1.6);
    grid on; xlabel('Iteration'); ylabel('Best-so-far fitness');
    title(sprintf('%s (D=%d)', name, dim));
end

fprintf(['\nNote: nfe is roughly 2.2-2.5 times N*T, because one CLCO iteration\n' ...
         'evaluates the coordination-field candidates, the crystal-field\n' ...
         'candidates, the Jahn-Teller resets and the ligand exchanges.\n']);
