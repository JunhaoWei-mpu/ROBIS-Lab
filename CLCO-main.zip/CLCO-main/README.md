# CLCO — Coordination Core-Ligand Collaborative Optimizer

Reference implementation of the optimizer introduced in:

> Y. Li, J. Wei, S. Mirjalili, Y. Zhao, Z. Li, Z. Wang, S.-K. Im, X. Yang, Y. Wang,
> **"Coordination Core-Ligand Collaborative Optimizer (CLCO): A chemistry-inspired
> metaheuristic for global numerical optimization, space–air–ground path planning,
> and constrained engineering design"**,
> *Advanced Engineering Informatics*, **76**:105092, 2026.

CLCO maps optimization onto a coordination-compound system: a **central ion** (the
incumbent best solution) interacts with a population of **ligands** (candidate
solutions) through five mechanisms — coordination-field formation, crystal-field
splitting, Jahn–Teller distortion, ligand exchange, and central-ion migration.

Every code block carries the number of the equation or algorithm line of the
article that it implements, so the source can be read side by side with Section 2
and Algorithm 1.

```
CLCO.m                the optimizer, MATLAB (single file, no toolboxes)
clco.py               the optimizer, Python (NumPy only) — statement-by-statement equivalent
demo_quick_start.m    minimal MATLAB example: three test functions + convergence plots
```

---

## Quick start

### MATLAB (R2018b or newer; no toolboxes) — also runs in GNU Octave

```matlab
f = @(x) sum(x.^2);                        % minimise the sphere function
[best_x, best_f, curve, nfe] = CLCO(30, 500, -100, 100, 30, f);
%                                  N   T    lb    ub  dim
fprintf('best = %.4e  (nfe = %d)\n', best_f, nfe);

demo_quick_start                           % three functions + convergence plots
```

The argument order `CLCO(N, T, lb, ub, dim, fobj)` deliberately matches the
GWO / WOA / DBO reference codes, so CLCO drops into an existing comparison
harness unchanged. A fifth argument `opts` (struct) overrides the four factors
and sets the random seed.

### Python (3.9+, NumPy only)

```python
import numpy as np
from clco import clco

res = clco(lambda x: float(np.sum(x**2)), dim=30, lb=-100, ub=100,
           N=30, T=500, seed=0)
print(res.f, res.nfe)
print(res.curve)                           # best-so-far per iteration
```

---

## Parameters

| Symbol | Meaning | Recommended value | Where in the article |
|---|---|---|---|
| `alpha0` | coordination-field strength factor | **1.8** | Eqs. (5)–(7) |
| `beta0`  | Jahn–Teller distortion factor      | **0.3** | Eq. (13) |
| `gamma0` | crystal-field splitting factor     | **0.6** | Eqs. (8)–(11) |
| `delta0` | ligand-exchange base rate          | **0.2** | Eq. (15) |
| `N`      | population size (coordination number) | 30 (benchmarks) / 50 (applications) | Sections 3, 4, 7 |
| `T`      | maximum iterations                 | 500 (benchmarks, path planning) / 50 (engineering) | Sections 3, 4, 7 |

The four factors are **Configuration 59** of Table 8, the setting recommended by
the full-factorial grid search of Section 3.4; they are the defaults in both
implementations. All remaining constants (the 0.7 strong-field threshold, the
0.3/0.7 band cut-offs, the 30-iteration Jahn–Teller safeguard, …) are the fixed
structural values of Table 5 and are hard-coded with an inline comment pointing
at the table row.

---

## Evaluation budget

One CLCO iteration evaluates the objective more than `N` times: `N` in the
coordination-field phase, `N - 1` in the crystal-field phase, plus the
Jahn–Teller resets and two evaluations per ligand exchange. Measured cost is
about `2.2 N` to `2.5 N` per iteration, i.e. roughly `3.6e4` evaluations for
`N = 30, T = 500` rather than `N * T = 1.5e4`.

Both implementations return the exact count as `nfe`, so this is always visible.
When comparing against fixed-population baselines under an equal
function-evaluation budget, use the Python `max_nfe` argument:

```python
res = clco(f, dim=30, lb=-100, ub=100, N=30, T=500, max_nfe=15000)
```

---

## Citation

See `CITATION.bib` / `CITATION.cff`. Released under the MIT License.
