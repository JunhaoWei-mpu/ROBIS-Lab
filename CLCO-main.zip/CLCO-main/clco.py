"""
Coordination Core-Ligand Collaborative Optimizer (CLCO) -- reference implementation.

Reference
---------
Y. Li, J. Wei, S. Mirjalili, Y. Zhao, Z. Li, Z. Wang, S.-K. Im, X. Yang, Y. Wang,
"Coordination Core-Ligand Collaborative Optimizer (CLCO): A chemistry-inspired
metaheuristic for global numerical optimization, space-air-ground path planning,
and constrained engineering design",
Advanced Engineering Informatics, vol. 76, p. 105092, 2026.

Every block below is annotated with the equation / algorithm-line number of the
published paper it implements, so the code can be read side by side with Section 2
("Coordination Core-Ligand Collaborative Optimizer (CLCO)") and Algorithm 1.

Notation note (important for reproducibility)
--------------------------------------------
Several equations of the paper contain the symbol ``(ub - lb)`` in a *scalar*
role: as a length scale for the distance kernel of Eq. (3), for the Jahn-Teller
symmetry threshold of Eq. (12) and for the distortion amplitude of Eq. (13).
Where a scalar is required, this implementation uses the Euclidean length of the
bounding box, ``box = ||ub - lb||``, which is the quantity used in the authors'
original MATLAB code. Where a per-dimension vector is required (initialisation,
Eq. (1), and the global reset of Eq. (14)), the vector ``ub - lb`` is used.

Minimisation is assumed throughout.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence

import numpy as np

__all__ = ["CLCOResult", "clco", "CLCO"]

# Guard used in Eqs. (3) and (4) of the paper to avoid division by zero.
EPS = 1e-12


@dataclass
class CLCOResult:
    """Outcome of a CLCO run.

    Attributes
    ----------
    x : best solution found (shape ``(dim,)``).
    f : fitness of ``x``.
    curve : best-so-far fitness after each iteration (length ``T``).
    nfe : number of objective-function evaluations actually consumed.
    """

    x: np.ndarray
    f: float
    curve: np.ndarray = field(repr=False)
    nfe: int = 0


def clco(
    fobj: Callable[[np.ndarray], float],
    dim: int,
    lb,
    ub,
    N: int = 30,
    T: int = 500,
    alpha0: float = 1.8,
    beta0: float = 0.3,
    gamma0: float = 0.6,
    delta0: float = 0.2,
    seed: Optional[int] = None,
    rng: Optional[np.random.Generator] = None,
    max_nfe: Optional[int] = None,
) -> CLCOResult:
    """Run the Coordination Core-Ligand Collaborative Optimizer.

    Parameters
    ----------
    fobj
        Objective function to *minimise*; called as ``fobj(x)`` with ``x`` a
        1-D array of length ``dim`` and returning a scalar.
    dim
        Problem dimension.
    lb, ub
        Lower / upper bounds. Either scalars or array-likes of length ``dim``.
    N
        Population size (the "coordination number", i.e. number of ligands).
        The paper uses ``N = 30`` for the CEC benchmarks and ``N = 50`` for the
        path-planning and engineering-design problems.
    T
        Maximum number of iterations. ``T = 500`` for the benchmarks and the
        path-planning problems, ``T = 50`` for the engineering-design problems.
    alpha0, beta0, gamma0, delta0
        Base values of the coordination-field strength factor, the Jahn-Teller
        distortion factor, the crystal-field splitting factor and the ligand
        exchange base rate. The defaults are "Configuration 59" of Table 8,
        i.e. the setting selected by the full-factorial grid search of
        Section 3.4 and recommended by the paper.
    seed, rng
        Reproducibility controls. Provide either an integer ``seed`` or a
        pre-built ``numpy.random.Generator``.
    max_nfe
        Optional hard cap on the number of function evaluations. When the cap is
        reached the run stops early and the remaining entries of ``curve`` are
        filled with the incumbent best. **This is not the protocol of the
        published paper** (which terminates on the iteration count ``T``); it is
        provided for readers who wish to compare algorithms under a strictly
        equal evaluation budget. See the "Evaluation budget" note below.

    Returns
    -------
    CLCOResult

    Notes
    -----
    **Evaluation budget.** One iteration consumes a *variable* number of
    function evaluations, roughly ``2.2 N`` to ``2.5 N``: ``N`` for the
    coordination-field phase, ``N - 1`` for the crystal-field phase, plus the
    Jahn-Teller resets, the two re-evaluations per ligand exchange and at most
    one central-ion refinement. With the paper's benchmark setting
    ``N = 30, T = 500`` this amounts to roughly ``3.6e4`` evaluations rather than
    ``N * T = 1.5e4``. ``CLCOResult.nfe`` always reports the exact count; pass
    ``max_nfe`` if a strict budget is required.
    """
    if rng is None:
        rng = np.random.default_rng(seed)

    lb = np.broadcast_to(np.asarray(lb, dtype=float), (dim,)).copy()
    ub = np.broadcast_to(np.asarray(ub, dtype=float), (dim,)).copy()
    if np.any(ub < lb):
        raise ValueError("ub must be >= lb in every dimension")

    # Scalar length scale of the search box; see the "Notation note" above.
    box = float(np.linalg.norm(ub - lb))
    if box == 0.0:
        raise ValueError("degenerate search box: ub == lb in every dimension")

    nfe = 0
    budget = np.inf if max_nfe is None else int(max_nfe)

    def evaluate(x: np.ndarray) -> float:
        nonlocal nfe
        nfe += 1
        return float(fobj(x))

    # ------------------------------------------------------------------
    # Population initialisation -- Section 2.2, Eqs. (1) and (2)
    # ------------------------------------------------------------------
    # Eq. (1): the central ion (the incumbent best solution) is placed
    # uniformly at random inside the box.
    center = lb + (ub - lb) * rng.random(dim)
    center_f = evaluate(center)

    # Eq. (2): the ligands form a "coordination sphere" around the central ion.
    # A random direction is drawn, normalised, and scaled by an initial
    # coordination distance 0.3 * box * rand().
    ligands = np.empty((N, dim))
    for i in range(N):
        direction = rng.standard_normal(dim)
        norm = np.linalg.norm(direction)
        direction = direction / norm if norm > 0 else np.zeros(dim)
        distance = 0.3 * box * rng.random()
        ligands[i] = np.clip(center + distance * direction, lb, ub)
    ligand_f = np.array([evaluate(ligands[i]) for i in range(N)])

    # Global best tracker (Algorithm 1, line 2).
    best_x = center.copy()
    best_f = center_f
    stall = 0  # consecutive iterations without an improvement of best_f

    curve = np.empty(T)

    # ==================================================================
    # Main loop -- Algorithm 1, lines 3-33
    # ==================================================================
    for t in range(1, T + 1):
        # Optional budget stop (not part of the published protocol). The check is
        # made between iterations, so the final iteration may overshoot the cap
        # by at most one iteration's worth of evaluations.
        if nfe >= budget:
            curve[t - 1:] = best_f
            break

        progress = t / T  # "progress" of Section 2.3

        # --------------------------------------------------------------
        # Dynamic parameter schedule -- Section 2.6 ("Algorithmic Process
        # Summary"). Before 70 % of the run alpha and beta decay linearly
        # while gamma grows; afterwards the three factors are held fixed.
        # --------------------------------------------------------------
        if progress < 0.7:
            alpha = alpha0 * (1.0 - 0.6 * progress)
            beta = beta0 * (1.0 - 0.4 * progress)
            gamma = gamma0 * (0.6 + 0.4 * progress)
        else:
            alpha = alpha0 * 0.3
            beta = beta0 * 0.4
            gamma = gamma0 * 0.8

        # Eq. (15): sinusoidal modulation of the ligand-exchange probability,
        # oscillating inside [0.4 * delta0, delta0] with a period of 100 iterations.
        delta = delta0 * (0.7 + 0.3 * np.sin(2.0 * np.pi * t / 100.0))

        # Stagnation safeguard (Algorithm 1, lines 5-7): after 20 iterations
        # without progress, temporarily boost the global step size.
        if stall > 20:
            alpha = 0.8 * alpha0
            beta = 0.7 * beta0
            stall = 0

        # --------------------------------------------------------------
        # (1) Coordination field formation -- Section 2.3.1, Eqs. (3)-(7)
        # --------------------------------------------------------------
        # Eq. (3): distance kernel divided by the relative fitness ratio.
        distances = np.linalg.norm(ligands - center, axis=1)
        fitness_ratio = ligand_f / (center_f + EPS)
        strength = np.exp(-distances / box) / (fitness_ratio + EPS)
        # Eq. (4): max-normalisation, which maps the raw scores onto (0, 1]
        # so that the fixed 0.7 threshold below is scale-invariant.
        strength = strength / (strength.max() + EPS)

        for i in range(N):
            if strength[i] > 0.7 and rng.random() > 0.3 * progress:
                # Eq. (5) -- strong coordination field: refine towards the
                # central ion with a step in [1.5, 2.5] * alpha * strength.
                step = alpha * strength[i] * (1.5 + rng.random())
                direction = center - ligands[i]
            elif rng.random() < 0.2 + 0.3 * (1.0 - progress):
                # Eq. (6) -- adaptive mode, global-exploration branch.
                # Selection probability decays linearly from 0.5 to 0.2.
                step = alpha * strength[i] * (1.5 + rng.random())
                direction = rng.standard_normal(dim)
            else:
                # Eq. (7) -- adaptive mode, local-search branch: a pull
                # towards the central ion plus Gaussian jitter, with a step
                # roughly one order of magnitude smaller than the global one.
                step = alpha * strength[i] * (0.3 + 0.2 * rng.random())
                direction = (center - ligands[i]) + 0.3 * rng.standard_normal(dim)

            candidate = np.clip(ligands[i] + step * direction, lb, ub)
            candidate_f = evaluate(candidate)
            # Greedy per-ligand acceptance (Algorithm 1, line 13).
            if candidate_f < ligand_f[i]:
                ligands[i] = candidate
                ligand_f[i] = candidate_f

        # --------------------------------------------------------------
        # (2) Crystal field splitting -- Section 2.3.2, Eqs. (8)-(11)
        # --------------------------------------------------------------
        order = np.argsort(ligand_f, kind="stable")
        rank_of = np.empty(N, dtype=int)
        rank_of[order] = np.arange(1, N + 1)  # 1 = best, N = worst
        x_best = ligands[order[0]].copy()
        x_worst = ligands[order[-1]].copy()
        elite = order[0]  # the single best ligand is carried over unchanged

        for i in range(N):
            if i == elite:
                continue
            rank_ratio = rank_of[i] / N  # in (0, 1]

            if rank_ratio < 0.3:
                # Eq. (8) -- high-energy band (t2g analogue): fine local search.
                field = gamma * 0.3
                direction = x_best - ligands[i]
            elif rank_ratio > 0.7:
                # Eqs. (9)-(10) -- low-energy band (eg analogue): coarse exploration.
                field = gamma * (1.5 + 0.5 * rng.random())
                if rng.random() < 0.4 * (1.0 - progress):
                    direction = rng.standard_normal(dim)          # Eq. (9), random
                else:                                             # Eq. (10), directional
                    direction = (x_best - x_worst) + rng.standard_normal(dim)
            else:
                # Eq. (11) -- mid-energy band: balanced search.
                field = gamma * (0.8 + 0.4 * rng.random())
                direction = (x_best - ligands[i]) + 0.5 * rng.standard_normal(dim)

            # Multiplicative jitter so that ligands of the same band do not
            # take identical step lengths (Table 5, "Step jitter").
            step = field * (1.0 + 0.2 * rng.standard_normal())
            candidate = np.clip(ligands[i] + step * direction, lb, ub)
            candidate_f = evaluate(candidate)
            if candidate_f < ligand_f[i]:
                ligands[i] = candidate
                ligand_f[i] = candidate_f

        # --------------------------------------------------------------
        # (3) Jahn-Teller distortion -- Section 2.3.3, Eqs. (12)-(14)
        # --------------------------------------------------------------
        centroid = ligands.mean(axis=0)
        sym_dev = float(np.linalg.norm(ligands - centroid, axis=1).mean())
        diversity = float(np.std(ligand_f))

        # Eq. (12): two diagnosis clauses plus a low-frequency periodic safeguard.
        needs_jt = (diversity < 1e-8) or (sym_dev < 0.1 * box) or (t % 30 == 0)

        if needs_jt:
            jt = beta * (1.0 + 0.5 * (1.0 - progress))

            # Eq. (13): displace the central ion along one randomly chosen axis
            # by 0.15 * box (sign drawn with equal probability), then add a small
            # isotropic jitter over all coordinates.
            distortion = np.zeros(dim)
            axis = rng.integers(dim)
            sign = 1.0 if rng.random() > 0.5 else -1.0
            distortion[axis] = sign * jt * box * 0.15
            distortion += 0.2 * jt * (rng.random(dim) - 0.5)

            candidate = np.clip(center + distortion, lb, ub)
            candidate_f = evaluate(candidate)
            if candidate_f < center_f:  # greedy: the incumbent can never worsen
                center = candidate
                center_f = candidate_f

            # Eq. (14): reset the bottom 50 % of the *ranked* ligands, each with
            # probability 0.4 + 0.3 (1 - progress); 70 % of the resets are global
            # and 30 % are local, i.e. placed on a sphere around the best ligand.
            reset_prob = 0.4 + 0.3 * (1.0 - progress)
            for idx in order[N // 2:]:
                if rng.random() >= reset_prob:
                    continue
                if rng.random() < 0.7:
                    ligands[idx] = lb + (ub - lb) * rng.random(dim)
                else:
                    direction = rng.standard_normal(dim)
                    norm = np.linalg.norm(direction)
                    direction = direction / norm if norm > 0 else np.zeros(dim)
                    distance = 0.3 * box * rng.random()
                    ligands[idx] = np.clip(x_best + distance * direction, lb, ub)
                ligand_f[idx] = evaluate(ligands[idx])

        # --------------------------------------------------------------
        # (4) Ligand exchange -- Section 2.3.4, Eqs. (15)-(18)
        # --------------------------------------------------------------
        # A symmetric in-place swap of a random subset of dimensions. It is not
        # a uniform crossover: no offspring is created, the population size is
        # preserved exactly, and both partners are re-evaluated afterwards.
        mean_f = float(ligand_f.mean())
        for i in range(N):
            if rng.random() >= delta:
                continue

            # Partner selection: 0.4 better-than-average / 0.3 uniformly random /
            # 0.3 worse-than-average (Table 5, "Partner-selection split").
            u = rng.random()
            if u < 0.4:
                pool = np.flatnonzero((ligand_f < mean_f) & (np.arange(N) != i))
            elif u < 0.7:
                pool = np.array([], dtype=int)  # fall through to uniform choice
            else:
                pool = np.flatnonzero((ligand_f > mean_f) & (np.arange(N) != i))

            if pool.size:
                j = int(rng.choice(pool))
            else:
                j = int(rng.integers(N - 1))
                if j >= i:
                    j += 1  # uniform over {0..N-1} \ {i}

            # Random binary mask: each dimension is swapped with probability
            # r = 0.4 + 0.3 * rand() in [0.4, 0.7] (partial crossover).
            r = 0.4 + 0.3 * rng.random()
            mask = rng.random(dim) < r
            if not mask.any():
                continue

            tmp = ligands[i, mask].copy()
            ligands[i, mask] = ligands[j, mask]
            ligands[j, mask] = tmp
            # Non-greedy: the swap is always kept, both partners are re-evaluated.
            ligand_f[i] = evaluate(ligands[i])
            ligand_f[j] = evaluate(ligands[j])

        # --------------------------------------------------------------
        # (5) Central ion update -- Section 2.3.5, Eqs. (19)-(20)
        # --------------------------------------------------------------
        i_star = int(np.argmin(ligand_f))
        if ligand_f[i_star] < center_f:
            # Eq. (19): migrate to the better ligand.
            center = ligands[i_star].copy()
            center_f = float(ligand_f[i_star])
        elif rng.random() < 0.3 * (1.0 - progress):
            # Eq. (20): otherwise, with a probability that decays to zero,
            # apply a small greedy relaxation step. The two cases are mutually
            # exclusive (Algorithm 1, lines 26-30).
            candidate = np.clip(
                center + 0.03 * (1.0 - progress) * (rng.random(dim) - 0.5), lb, ub
            )
            candidate_f = evaluate(candidate)
            if candidate_f < center_f:
                center = candidate
                center_f = candidate_f

        # Global best bookkeeping and the stagnation counter (lines 31-32).
        if center_f < best_f:
            best_x = center.copy()
            best_f = center_f
            stall = 0
        else:
            stall += 1

        curve[t - 1] = best_f

    return CLCOResult(x=best_x, f=best_f, curve=curve, nfe=nfe)


class CLCO:
    """Thin object-oriented wrapper around :func:`clco`.

    Useful when the same configuration is applied to many problems::

        opt = CLCO(N=50, T=50)
        res = opt.minimize(f, dim=7, lb=lb, ub=ub, seed=0)
    """

    def __init__(
        self,
        N: int = 30,
        T: int = 500,
        alpha0: float = 1.8,
        beta0: float = 0.3,
        gamma0: float = 0.6,
        delta0: float = 0.2,
    ) -> None:
        self.N = N
        self.T = T
        self.alpha0 = alpha0
        self.beta0 = beta0
        self.gamma0 = gamma0
        self.delta0 = delta0

    def minimize(
        self,
        fobj: Callable[[np.ndarray], float],
        dim: int,
        lb,
        ub,
        seed: Optional[int] = None,
        rng: Optional[np.random.Generator] = None,
    ) -> CLCOResult:
        return clco(
            fobj,
            dim,
            lb,
            ub,
            N=self.N,
            T=self.T,
            alpha0=self.alpha0,
            beta0=self.beta0,
            gamma0=self.gamma0,
            delta0=self.delta0,
            seed=seed,
            rng=rng,
        )

    def run_many(
        self,
        fobj: Callable[[np.ndarray], float],
        dim: int,
        lb,
        ub,
        runs: int = 30,
        base_seed: int = 0,
    ) -> Sequence[CLCOResult]:
        """Perform ``runs`` independent runs with seeds ``base_seed + k``."""
        return [
            self.minimize(fobj, dim, lb, ub, seed=base_seed + k) for k in range(runs)
        ]
