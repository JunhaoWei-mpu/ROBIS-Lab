function [Best_pos, Best_score, Convergence_curve, nfe] = CLCO(N, T, lb, ub, dim, fobj, opts)
%CLCO  Coordination Core-Ligand Collaborative Optimizer.
%
%   [Best_pos, Best_score, Convergence_curve] = CLCO(N, T, lb, ub, dim, fobj)
%   minimises the objective FOBJ over the box [LB, UB] using a population of N
%   ligands for T iterations. The argument order follows the convention used by
%   the GWO/WOA/DBO reference codes so that CLCO can be dropped into an existing
%   comparison harness unchanged.
%
%   Inputs
%     N     - population size (coordination number). Paper: 30 for the CEC
%             benchmarks, 50 for path planning and engineering design.
%     T     - maximum number of iterations. Paper: 500 (benchmarks, path
%             planning), 50 (engineering design).
%     lb,ub - lower / upper bounds; scalar or 1 x dim row vectors.
%     dim   - problem dimension.
%     fobj  - function handle, called as fobj(x) with x a 1 x dim row vector.
%     opts  - (optional) struct with fields alpha0, beta0, gamma0, delta0 and
%             seed. Defaults are "Configuration 59" of Table 8, the setting
%             recommended by the full-factorial grid search of Section 3.4:
%                 alpha0 = 1.8   coordination-field strength factor
%                 beta0  = 0.3   Jahn-Teller distortion factor
%                 gamma0 = 0.6   crystal-field splitting factor
%                 delta0 = 0.2   ligand-exchange base rate
%
%   Outputs
%     Best_pos          - best solution found (1 x dim).
%     Best_score        - its objective value.
%     Convergence_curve - best-so-far value after each iteration (T x 1).
%     nfe               - number of objective evaluations actually consumed.
%
%   Reference
%     Y. Li, J. Wei, S. Mirjalili, Y. Zhao, Z. Li, Z. Wang, S.-K. Im, X. Yang,
%     Y. Wang, "Coordination Core-Ligand Collaborative Optimizer (CLCO): A
%     chemistry-inspired metaheuristic for global numerical optimization,
%     space-air-ground path planning, and constrained engineering design",
%     Advanced Engineering Informatics, 76:105092, 2026.
%
%   Every block below carries the number of the equation / algorithm line of the
%   paper that it implements (Section 2 and Algorithm 1).
%
%   Notation note. Several equations use "(ub - lb)" as a *scalar* length scale
%   (the distance kernel of Eq. (3), the Jahn-Teller symmetry threshold of
%   Eq. (12), the distortion amplitude of Eq. (13)). Wherever a scalar is
%   required this implementation uses box = norm(ub - lb); wherever a
%   per-dimension vector is required (Eq. (1) and the global reset of Eq. (14))
%   the vector ub - lb is used.
%
%   Evaluation budget. One iteration costs roughly 2.2*N to 2.5*N evaluations
%   (N for the coordination field, N-1 for the crystal field, plus Jahn-Teller
%   resets and two per ligand exchange), not N. NFE reports the exact count.
%
%   Example
%     f = @(x) sum(x.^2);
%     [x, fval] = CLCO(30, 500, -100, 100, 30, f);

% ------------------------------------------------------------------------
% Argument handling and defaults
% ------------------------------------------------------------------------
if nargin < 7, opts = struct(); end
if ~isfield(opts, 'alpha0'), opts.alpha0 = 1.8; end
if ~isfield(opts, 'beta0'),  opts.beta0  = 0.3; end
if ~isfield(opts, 'gamma0'), opts.gamma0 = 0.6; end
if ~isfield(opts, 'delta0'), opts.delta0 = 0.2; end
if isfield(opts, 'seed'), rng(opts.seed); end

alpha0 = opts.alpha0;  beta0 = opts.beta0;
gamma0 = opts.gamma0;  delta0 = opts.delta0;

EPS = 1e-12;    % guard of Eqs. (3) and (4)

% Broadcast scalar bounds and force row vectors.
if isscalar(lb), lb = repmat(lb, 1, dim); end
if isscalar(ub), ub = repmat(ub, 1, dim); end
lb = reshape(lb, 1, dim);
ub = reshape(ub, 1, dim);
if any(ub < lb)
    error('CLCO:bounds', 'ub must be >= lb in every dimension');
end

box = norm(ub - lb);           % scalar length scale, see the notation note
if box == 0
    error('CLCO:bounds', 'degenerate search box: ub == lb everywhere');
end

nfe = 0;

% ------------------------------------------------------------------------
% Population initialisation -- Section 2.2, Eqs. (1) and (2)
% ------------------------------------------------------------------------
% Eq. (1): the central ion (the incumbent best) is placed uniformly at random.
center = lb + (ub - lb) .* rand(1, dim);
center_f = fobj(center);  nfe = nfe + 1;

% Eq. (2): the ligands form a coordination sphere around the central ion; a
% random direction is normalised and scaled by 0.3 * box * rand().
ligands = zeros(N, dim);
ligand_f = zeros(N, 1);
for i = 1:N
    direction = randn(1, dim);
    nrm = norm(direction);
    if nrm > 0, direction = direction / nrm; else, direction = zeros(1, dim); end
    distance = 0.3 * box * rand();
    ligands(i, :) = min(max(center + distance * direction, lb), ub);
    ligand_f(i) = fobj(ligands(i, :));  nfe = nfe + 1;
end

% Global best tracker (Algorithm 1, line 2).
Best_pos = center;
Best_score = center_f;
stall = 0;                     % consecutive iterations without improvement

Convergence_curve = zeros(T, 1);

% ========================================================================
% Main loop -- Algorithm 1, lines 3-33
% ========================================================================
for t = 1:T
    progress = t / T;

    % --------------------------------------------------------------------
    % Dynamic parameter schedule -- Section 2.6. Before 70 % of the run
    % alpha and beta decay linearly while gamma grows; afterwards the three
    % factors are held fixed.
    % --------------------------------------------------------------------
    if progress < 0.7
        alpha = alpha0 * (1 - 0.6 * progress);
        beta  = beta0  * (1 - 0.4 * progress);
        gamma = gamma0 * (0.6 + 0.4 * progress);
    else
        alpha = alpha0 * 0.3;
        beta  = beta0  * 0.4;
        gamma = gamma0 * 0.8;
    end

    % Eq. (15): sinusoidal modulation of the exchange probability, oscillating
    % inside [0.4*delta0, delta0] with a period of 100 iterations.
    delta = delta0 * (0.7 + 0.3 * sin(2 * pi * t / 100));

    % Stagnation safeguard (Algorithm 1, lines 5-7).
    if stall > 20
        alpha = 0.8 * alpha0;
        beta  = 0.7 * beta0;
        stall = 0;
    end

    % --------------------------------------------------------------------
    % (1) Coordination field formation -- Section 2.3.1, Eqs. (3)-(7)
    % --------------------------------------------------------------------
    distances = sqrt(sum((ligands - center).^2, 2));          % Euclidean
    fitness_ratio = ligand_f ./ (center_f + EPS);
    strength = exp(-distances / box) ./ (fitness_ratio + EPS);   % Eq. (3)
    strength = strength / (max(strength) + EPS);                 % Eq. (4)

    for i = 1:N
        if strength(i) > 0.7 && rand() > 0.3 * progress
            % Eq. (5) -- strong field: refine towards the central ion,
            % step in [1.5, 2.5] * alpha * strength.
            step = alpha * strength(i) * (1.5 + rand());
            direction = center - ligands(i, :);
        elseif rand() < 0.2 + 0.3 * (1 - progress)
            % Eq. (6) -- adaptive mode, global exploration. The selection
            % probability decays linearly from 0.5 to 0.2.
            step = alpha * strength(i) * (1.5 + rand());
            direction = randn(1, dim);
        else
            % Eq. (7) -- adaptive mode, local search: pull towards the
            % central ion plus Gaussian jitter, roughly one order of
            % magnitude smaller than the global branch.
            step = alpha * strength(i) * (0.3 + 0.2 * rand());
            direction = (center - ligands(i, :)) + 0.3 * randn(1, dim);
        end

        candidate = min(max(ligands(i, :) + step * direction, lb), ub);
        candidate_f = fobj(candidate);  nfe = nfe + 1;
        if candidate_f < ligand_f(i)             % greedy acceptance, line 13
            ligands(i, :) = candidate;
            ligand_f(i) = candidate_f;
        end
    end

    % --------------------------------------------------------------------
    % (2) Crystal field splitting -- Section 2.3.2, Eqs. (8)-(11)
    % --------------------------------------------------------------------
    [~, order] = sort(ligand_f);              % order(1) = best, order(N) = worst
    rank_of = zeros(N, 1);
    rank_of(order) = 1:N;
    x_best  = ligands(order(1), :);
    x_worst = ligands(order(end), :);
    elite   = order(1);                       % the best ligand is carried over

    for i = 1:N
        if i == elite, continue; end
        rank_ratio = rank_of(i) / N;          % in (0, 1]

        if rank_ratio < 0.3
            % Eq. (8) -- high-energy band (t2g analogue): fine local search.
            field = gamma * 0.3;
            direction = x_best - ligands(i, :);
        elseif rank_ratio > 0.7
            % Eqs. (9)-(10) -- low-energy band (eg analogue): coarse exploration.
            field = gamma * (1.5 + 0.5 * rand());
            if rand() < 0.4 * (1 - progress)
                direction = randn(1, dim);                          % Eq. (9), random
            else
                direction = (x_best - x_worst) + randn(1, dim);     % Eq. (10), directional
            end
        else
            % Eq. (11) -- mid-energy band: balanced search.
            field = gamma * (0.8 + 0.4 * rand());
            direction = (x_best - ligands(i, :)) + 0.5 * randn(1, dim);
        end

        % Multiplicative jitter (Table 5, "Step jitter") so that ligands in the
        % same band do not take identical step lengths.
        step = field * (1 + 0.2 * randn());
        candidate = min(max(ligands(i, :) + step * direction, lb), ub);
        candidate_f = fobj(candidate);  nfe = nfe + 1;
        if candidate_f < ligand_f(i)
            ligands(i, :) = candidate;
            ligand_f(i) = candidate_f;
        end
    end

    % --------------------------------------------------------------------
    % (3) Jahn-Teller distortion -- Section 2.3.3, Eqs. (12)-(14)
    % --------------------------------------------------------------------
    centroid = mean(ligands, 1);
    sym_dev = mean(sqrt(sum((ligands - centroid).^2, 2)));
    diversity = std(ligand_f, 1);             % population fitness std

    % Eq. (12): two diagnosis clauses plus a low-frequency periodic safeguard.
    needs_jt = (diversity < 1e-8) || (sym_dev < 0.1 * box) || (mod(t, 30) == 0);

    if needs_jt
        jt = beta * (1 + 0.5 * (1 - progress));

        % Eq. (13): displace the central ion along one random axis by
        % 0.15 * box (sign uniform), then add a small isotropic jitter.
        distortion = zeros(1, dim);
        axis_idx = randi(dim);
        if rand() > 0.5, sgn = 1; else, sgn = -1; end
        distortion(axis_idx) = sgn * jt * box * 0.15;
        distortion = distortion + 0.2 * jt * (rand(1, dim) - 0.5);

        candidate = min(max(center + distortion, lb), ub);
        candidate_f = fobj(candidate);  nfe = nfe + 1;
        if candidate_f < center_f          % greedy: the incumbent never worsens
            center = candidate;
            center_f = candidate_f;
        end

        % Eq. (14): reset the bottom 50 % of the *ranked* ligands, each with
        % probability 0.4 + 0.3(1 - progress); 70 % global, 30 % near the best.
        reset_prob = 0.4 + 0.3 * (1 - progress);
        for k = (floor(N / 2) + 1):N
            idx = order(k);
            if rand() >= reset_prob, continue; end
            if rand() < 0.7
                ligands(idx, :) = lb + (ub - lb) .* rand(1, dim);
            else
                direction = randn(1, dim);
                nrm = norm(direction);
                if nrm > 0, direction = direction / nrm; else, direction = zeros(1, dim); end
                distance = 0.3 * box * rand();
                ligands(idx, :) = min(max(x_best + distance * direction, lb), ub);
            end
            ligand_f(idx) = fobj(ligands(idx, :));  nfe = nfe + 1;
        end
    end

    % --------------------------------------------------------------------
    % (4) Ligand exchange -- Section 2.3.4, Eqs. (15)-(18)
    % --------------------------------------------------------------------
    % A symmetric in-place swap of a random subset of dimensions: no offspring
    % is produced, the population size is preserved, both partners are
    % re-evaluated afterwards (non-greedy).
    mean_f = mean(ligand_f);
    for i = 1:N
        if rand() >= delta, continue; end

        % Partner selection: 0.4 better-than-average / 0.3 uniform / 0.3
        % worse-than-average (Table 5, "Partner-selection split").
        u = rand();
        if u < 0.4
            pool = find(ligand_f < mean_f);
        elseif u < 0.7
            pool = [];                     % fall through to a uniform draw
        else
            pool = find(ligand_f > mean_f);
        end
        pool(pool == i) = [];

        if ~isempty(pool)
            j = pool(randi(numel(pool)));
        else
            j = randi(N - 1);
            if j >= i, j = j + 1; end      % uniform over {1..N} \ {i}
        end

        % Random binary mask: each dimension swapped with probability
        % r = 0.4 + 0.3*rand() in [0.4, 0.7] (partial crossover).
        r = 0.4 + 0.3 * rand();
        mask = rand(1, dim) < r;
        if ~any(mask), continue; end

        tmp = ligands(i, mask);
        ligands(i, mask) = ligands(j, mask);
        ligands(j, mask) = tmp;
        ligand_f(i) = fobj(ligands(i, :));  nfe = nfe + 1;
        ligand_f(j) = fobj(ligands(j, :));  nfe = nfe + 1;
    end

    % --------------------------------------------------------------------
    % (5) Central ion update -- Section 2.3.5, Eqs. (19)-(20)
    % --------------------------------------------------------------------
    [min_f, i_star] = min(ligand_f);
    if min_f < center_f
        % Eq. (19): migrate to the better ligand.
        center = ligands(i_star, :);
        center_f = min_f;
    elseif rand() < 0.3 * (1 - progress)
        % Eq. (20): otherwise a small greedy relaxation step, whose amplitude
        % and probability both decay to zero. The two cases are mutually
        % exclusive (Algorithm 1, lines 26-30).
        candidate = min(max(center + 0.03 * (1 - progress) * (rand(1, dim) - 0.5), lb), ub);
        candidate_f = fobj(candidate);  nfe = nfe + 1;
        if candidate_f < center_f
            center = candidate;
            center_f = candidate_f;
        end
    end

    % Global best bookkeeping and stagnation counter (lines 31-32).
    if center_f < Best_score
        Best_pos = center;
        Best_score = center_f;
        stall = 0;
    else
        stall = stall + 1;
    end

    Convergence_curve(t) = Best_score;
end
end
